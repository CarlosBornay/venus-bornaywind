==================================================
Custom Datablock Example
==================================================

.. literalinclude:: ../../../examples/common/custom-datablock.py

