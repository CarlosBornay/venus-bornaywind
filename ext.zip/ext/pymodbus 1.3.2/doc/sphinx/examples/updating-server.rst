==================================================
Updating Server Example
==================================================

.. literalinclude:: ../../../examples/common/updating-server.py

