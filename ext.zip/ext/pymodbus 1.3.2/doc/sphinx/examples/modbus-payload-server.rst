==================================================
Modbus Payload Server Context Building Example
==================================================

.. literalinclude:: ../../../examples/common/modbus-payload-server.py

