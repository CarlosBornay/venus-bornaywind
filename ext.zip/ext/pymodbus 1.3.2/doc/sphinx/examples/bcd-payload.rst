==================================================
Binary Coded Decimal Example
==================================================

.. literalinclude:: ../../../examples/contrib/bcd-payload.py

